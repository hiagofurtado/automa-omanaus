# Automação com IA - App para Pequenos Negócios

Este projeto é um aplicativo web que permite automatizar tarefas repetitivas usando inteligência artificial.

## Tecnologias
- Frontend: React (pronto para Vercel)
- Backend: Flask (pronto para Render)

---

## 📦 Instruções para Deploy

### 🔹 Frontend (Vercel)
1. Suba a pasta `frontend/` em um repositório GitHub.
2. Vá até [https://vercel.com/import](https://vercel.com/import) e conecte esse repositório.
3. A Vercel vai gerar uma URL pública.

### 🔹 Backend (Render)
1. Suba a pasta `backend/` em outro repositório GitHub.
2. Vá até [https://dashboard.render.com/](https://dashboard.render.com/) e clique em **New > Web Service**.
3. Configure:
   - Runtime: Python 3
   - Build command: `pip install -r requirements.txt`
   - Start command: `python app.py`
   - Porta: 5000 (padrão Flask)

---

## ✅ Exemplo de uso
- O usuário descreve uma tarefa repetitiva no frontend.
- O backend responde com uma sugestão de automação simulada com IA.

