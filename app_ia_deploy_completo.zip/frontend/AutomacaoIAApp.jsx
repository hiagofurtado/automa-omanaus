import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Loader } from 'lucide-react';

export default function AutomacaoIAApp() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAutomate = async () => {
    setLoading(true);
    try {
      const response = await fetch('https://seu-backend-na-render.onrender.com/api/automate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input }),
      });
      const data = await response.json();
      setOutput(data.output);
    } catch (error) {
      setOutput('Erro ao processar. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Automatize seu Negócio com IA</h1>
      <p className="mb-4 text-gray-600">
        Insira uma descrição de uma tarefa repetitiva do seu negócio (como "gerar relatório semanal de vendas") e veja como ela pode ser automatizada com inteligência artificial.
      </p>

      <Textarea
        placeholder="Descreva aqui o processo que você quer automatizar..."
        value={input}
        onChange={(e) => setInput(e.target.value)}
        className="mb-4"
      />

      <Button onClick={handleAutomate} disabled={loading}>
        {loading ? <Loader className="animate-spin mr-2" /> : null}
        Automatizar
      </Button>

      {output && (
        <Card className="mt-6">
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">Solução Sugerida com IA</h2>
            <p className="whitespace-pre-wrap text-gray-800">{output}</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
