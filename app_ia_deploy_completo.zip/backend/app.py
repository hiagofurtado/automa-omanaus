from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Libera o acesso do frontend

@app.route('/api/automate', methods=['POST'])
def automate():
    data = request.json
    input_text = data.get('input', '')

    # Simulação da resposta da IA
    resposta_simulada = f"""
Sugestão de automação para: "{input_text}"

🔧 Etapas sugeridas:
1. Use uma ferramenta como Power Automate, Make ou Zapier para automatizar essa tarefa.
2. Crie um fluxo que colete os dados automaticamente.
3. Gere um relatório ou ação automática com base nessas informações.
4. Envie o resultado por e-mail ou salve em uma planilha automaticamente.

🧠 Dica: Com IA, você pode incluir análise de dados e alertas inteligentes!

Essa automação pode reduzir até 80% do tempo gasto com essa atividade.
    """

    return jsonify({'output': resposta_simulada.strip()})

if __name__ == '__main__':
    app.run(debug=True)
